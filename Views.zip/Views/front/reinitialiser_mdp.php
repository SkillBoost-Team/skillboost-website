<?php
session_start();
include '../front/config.php';

if (!isset($_SESSION['reset_email'])) {
    header("Location: mot_de_passe_oublie.php");
    exit();
}

if (isset($_POST['reinitialiser'])) {
    $nouveau_mdp = $_POST['nouveau_mdp'];
    $confirmer_mdp = $_POST['confirmer_mdp'];
    
    if ($nouveau_mdp !== $confirmer_mdp) {
        echo "<script>alert('Les mots de passe ne correspondent pas');</script>";
    } else {
        // Hachage sécurisé
        $mdp_hash = password_hash($nouveau_mdp, PASSWORD_BCRYPT);
        
        // Mise à jour en base
        $update = $conn->prepare("UPDATE utilisateurs SET mot_de_passe = ?, reset_token = NULL, reset_token_expiry = NULL WHERE email = ?");
        $update->bind_param("ss", $mdp_hash, $_SESSION['reset_email']);
        $update->execute();
        
        session_unset();
        session_destroy();
        echo "<script>alert('Mot de passe réinitialisé avec succès'); window.location='login.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Nouveau mot de passe</title>
</head>
<body>
    <div class="container mt-5">
        <h2>Choisissez un nouveau mot de passe</h2>
        <form method="POST">
            <div class="mb-3">
                <label>Nouveau mot de passe</label>
                <input type="password" name="nouveau_mdp" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Confirmer le mot de passe</label>
                <input type="password" name="confirmer_mdp" class="form-control" required>
            </div>
            <button type="submit" name="reinitialiser" class="btn btn-primary">
                Réinitialiser
            </button>
        </form>
    </div>
</body>
</html>