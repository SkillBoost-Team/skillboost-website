<?php
include 'config.php';

echo "✅ Connexion réussie à la base de données !";
?>