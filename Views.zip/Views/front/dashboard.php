<?php
session_start();

// Vérifie si l'utilisateur est connecté
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

$nom = $_SESSION['nom'];
$role = $_SESSION['role'];
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- Topbar -->
<div class="container-fluid bg-dark px-5 py-2 text-white d-flex justify-content-between align-items-center">
    <div>
        <strong>Bienvenue, <?= htmlspecialchars($nom) ?> (<?= htmlspecialchars($role) ?>)</strong>
    </div>
    <form action="logout.php" method="post">
        <button type="submit" class="btn btn-outline-light btn-sm">Déconnexion</button>
    </form>
</div>

<!-- Contenu principal -->
<div class="container mt-5">
    <h1 class="mb-4">Tableau de bord</h1>
    <p>Ceci est une page protégée que seuls les utilisateurs connectés peuvent voir.</p>
</div>

<!-- Footer -->
<footer class="container-fluid bg-dark text-white text-center py-3 mt-5">
    &copy; <?= date("Y") ?> SkillBoost. Tous droits réservés.
</footer>

</body>
</html>
