<?php
session_start();
if (!isset($_SESSION['reset_email'])) {
    header("Location: mot_de_passe_oublie.php");
    exit();
}

if (isset($_POST['verifier_code'])) {
    $code_saisi = $_POST['code'];
    
    if ($code_saisi == $_SESSION['code_verification']) {
        header("Location: reinitialiser_mdp.php");
        exit();
    } else {
        echo "<script>alert('Code incorrect');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Vérification du code</title>
</head>
<body>
    <div class="container mt-5">
        <h2>Entrez le code reçu par email</h2>
        <form method="POST">
            <div class="mb-3">
                <input type="text" name="code" class="form-control" required>
            </div>
            <button type="submit" name="verifier_code" class="btn btn-primary">
                Vérifier
            </button>
        </form>
    </div>
</body>
</html>