<?php
session_start();
include '../front/config.php';

if (isset($_POST['envoyer_code'])) {
    $email = $_POST['email'];
    
    // Vérifier si l'email existe
    $stmt = $conn->prepare("SELECT id FROM utilisateurs WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        // Générer un token (6 chiffres)
        $code = rand(100000, 999999);
        $token = bin2hex(random_bytes(32));
        $expiry = date("Y-m-d H:i:s", strtotime("+15 minutes"));
        
        // Stocker en base
        $update = $conn->prepare("UPDATE utilisateurs SET reset_token = ?, reset_token_expiry = ? WHERE email = ?");
        $update->bind_param("sss", $token, $expiry, $email);
        $update->execute();
        
        // Envoyer l'email (exemple basique)
        $sujet = "Réinitialisation de votre mot de passe";
        $message = "Votre code de vérification est : $code\n\n";
        $message .= "Cliquez ici pour réinitialiser : http://votresite.com/reinitialiser_mdp.php?token=$token";
        $headers = "From: no-reply@votresite.com";
        
        mail($email, $sujet, $message, $headers);
        
        $_SESSION['reset_email'] = $email;
        $_SESSION['code_verification'] = $code; // Stocker en session pour vérification
        header("Location: verification_code.php");
        exit();
    } else {
        echo "<script>alert('Email non trouvé');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Mot de passe oublié</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Récupération de mot de passe</h2>
        <form method="POST">
            <div class="mb-3">
                <label>Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <button type="submit" name="envoyer_code" class="btn btn-primary">
                Envoyer le code
            </button>
        </form>
    </div>
</body>
</html>